# Yash Patel
# CSC 242-405
# Assignment 2
# I worked alone

# 1

def evaluate():
    'asks for 4 inputs, gets the average of the first three, and compares the avg to the fourth input'

    x = eval(input('Enter a number for x: '))
    y = eval(input('Enter a number for y: '))
    z = eval(input('Enter a number for z: '))
    print('You have entered x = ', x, ', y = ', y, ', z = ', z)
    myAverage = eval(input('Enter what you think the average of x, y, and z is: '))
    if (x + y + z) / 3 == myAverage:
        print('Your average is correct.')
    else:
        print('Your average is not correct')
        print('    The correct average is: ', (x+y+z)/3)
        
    maxvalue = max(x, y, z)
    minvalue = min(x, y, z)
    print('The maximum value of x, y, and z = ', maxvalue)
    print('The min value of x, y, and z = ', minvalue)   


#2

def printDigits():
    'prints the digits using math functions in the integers requested and prints them using arithmetic'
    n = eval(input('Enter n: '))
    n4 = n % 10
    n3 = (n // 10) % 10
    n2 = (n // 100) % 10
    n1 = (n // 1000) % 10
    print(n1)
    print(n2)
    print(n3)
    print(n4)


#3

def returnN(s, n):
    'returns the first n characters of the string s; if the string s does not have n characters, then empty string should return'
    if len(s) < n:
        return ''
    else:
        return s[0:n]


#4

def weekPay(rate, hours):
    'given the hours worked and hourly wage equals the pay; overtime at 1.5 times regular pay'
    if hours <= 40:
        return rate*hours
    else:
        return (40*rate) + (hours-40) * (rate*1.5)


#5
    
def partition(lst, let1, let2):
    'prints the names that start with a letter between and including let1 and let2'
    for n in lst:
        if let1 <= n[0] <= let2:
            print(n)

