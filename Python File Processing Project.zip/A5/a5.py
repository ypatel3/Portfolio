# Yash Patel
# CSC 241-405
# Assignment 5
# I worked alone

#1.

def mult3(L):
    'asks to write a function that prints multiples of 3'
    for x in L:
        if x%3 == 0:
            print(x)


#2.

def inBoth(list1, list2):
    'asks to take two lists and return true if anything is common and false otherwise.'
    index = -1
    for i in range(len(list1)):
        for j in range(len(list2)):
            if(list1[i] == list2[j]):
                return True
    return False


#3.

def doubles(L):
    'asks to write a function that takes a list as a parameter and print one per line that is twice the previous integar.'
    l = len(L)
    for i in range(l-1):
        if L[i+1] == 2 * L[i]:
            print(L[i+1])


#4.

def intersect(list1, list2):
    'asks to take two lists of integers that are not duplicate value and return a list that are in both lists.'
    newList = []
    for x in list1:
        for y in list2:
            if(x==y):
                newList.append(x)
                break
    return newList






            


            

            

 
