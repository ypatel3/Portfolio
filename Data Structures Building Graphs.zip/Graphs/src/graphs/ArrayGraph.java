package graphs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * @author <Yash>
 */
public class ArrayGraph implements IndexedGraph
{
	private int numberOfEdges;
	private Collection<Integer>[] edges;
	private int vertices;
	
	@SuppressWarnings("unchecked")
	public ArrayGraph(int vertices)
	{
		this.vertices = vertices;
		this.edges = new Collection[vertices];
		for(int i=0; i<this.edges.length; i++) {
			this.edges[i] = new ArrayList<Integer>();
		}
	}

	@Override
	public int getNumberOfVerticies()
	{
		return this.vertices;
	}

	@Override
	public int getNumberOfEdges()
	{
		return this.numberOfEdges;
	}

	@Override
	public boolean addEdge(Integer from, Integer to)
	{
		if(from > 99 || from < 0 || to > 99 || to < 0) {
			return false;
		}
		edges[from].add(to);
		edges[to].add(from);
		numberOfEdges ++;
		return true;
	}

	@Override
	public Collection<Integer> getAdjacent(Integer to)
	{
		if(edges == null || edges[to] == null) {
			return new ArrayList<>();
		}
		return new ArrayList<>(edges[to]);
	}

	@Override
	public boolean removeEdge(Integer from, Integer to)
	{	
		boolean bool = false;
		Iterator<Integer> itr = edges[from].iterator();
		int num;
		while (itr.hasNext()) {
			num = itr.next();
			if(num == to) {
				itr.remove();
				bool = true;
				break;
			}
		}
		
		itr = edges[to].iterator();
		while (itr.hasNext()) {
			num = itr.next();
			if(num == from) {
				itr.remove();
				bool = true;
				break;
			}
		}
		if(bool) {
			numberOfEdges --;
		}
		return bool;	
	}
}