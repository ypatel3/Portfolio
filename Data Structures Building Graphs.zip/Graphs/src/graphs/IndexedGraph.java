package graphs;

/**
 * @author Yash
 */
public interface IndexedGraph extends Graph<Integer>
{

}