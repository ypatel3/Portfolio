package graphs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author <Yash>
 */
public class SymbolGraph<E> implements Graph<E>
{
	private Map<E, List<E>> edges;
	private int numberOfEdges;
	private int numberOfVertices;
	public SymbolGraph()
	{
		this.edges = new HashMap<>();
		this.numberOfEdges = 0;
		this.numberOfVertices = 0;
	}

	@Override
	public int getNumberOfVerticies()
	{
		return this.numberOfVertices;
	}

	@Override
	public int getNumberOfEdges()
	{
		return this.numberOfEdges;
	}

	public boolean addVertex(E value)
	{
		if(edges.containsKey(value)){
			return false;
		}
		edges.put(value, null);
		this.numberOfVertices ++;
		return true;
	}
	
	@Override
	public boolean addEdge(E from, E to)
	{
		if(!edges.containsKey(from) || !edges.containsKey(to))
			return false;
		List<E> list = edges.get(from);
		if(list == null) {
			list = new ArrayList<>();
		}
		list.add(to);
		edges.put(from, list);
		this.numberOfEdges++;
		return true;
	}

	@Override
	public Collection<E> getAdjacent(E to)
	{
		if(edges == null || edges.get(to) == null)
			return new ArrayList<>();
		return edges.get(to);
	}

	@Override
	public boolean removeEdge(E from, E to)
	{
		List<E> list = edges.get(from);
		if(list==null || !list.contains(to)) {
			return false;
		}
		list.remove(to);
		edges.put(from, list);
		this.numberOfEdges --;
		return true;
	}	
}