package graphs.queries;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

import graphs.ArrayGraph;
import graphs.IndexedGraph;

/**
 * @author <Yash>
 */
public class DepthFirstPath {
	IndexedGraph graph;
	int source;
	List<Integer> path;
	boolean b = false;
	List<Integer> maxList;
    List<Integer> myList;
	public DepthFirstPath(IndexedGraph g, int source) {
		this.graph = g;
		this.source = source;
		path = new ArrayList<>();
		maxList = new ArrayList<>();
	}

	/**
	 * Return a path from the vertex provided to the original source
	 * 
	 * @param to any vertex in the graph
	 * @return a collection of vertices that is the path, or an empty collection if
	 *         the vertex is not connected
	 */
	public Collection<Integer> getPath(int to) {
		boolean[] isVisited = new boolean[this.graph.getNumberOfVerticies()];
		path.add(this.source);		
		getPath(this.source, to, isVisited);
		Collections.reverse(this.path);
		return this.path;
	}

	private void getPath(Integer from, Integer to, boolean[] isVisited) {
		if (from.equals(to)) {
			b = true;
			return;
		}
		isVisited[from] = true;
		for (Integer i : this.graph.getAdjacent(from)) {
			if (!isVisited[i]) {
				if(!b)
					path.add(i);
				getPath(i, to, isVisited);
				if(!b)
					path.remove(i);
			}
		}
	}


	/**
	 * Check connectivity to the source vertex
	 * 
	 * @param vertex - the vertex to check connectivity
	 * @return true if connected
	 */
	public boolean isConnected(int vertex) {
		if(this.maxList.contains(vertex)) {
			return true;
		}
		return false;
	}

	/**
	 * Determine the number of vertices in the subgraph
	 * 
	 * @return the count
	 */
	public int getCount() {
		getMaxSubgraph();
		return maxList.size();
	}
	
	
    public void dfs(int vertex,boolean visited[])
    {
        visited[vertex] = true;
//        System.out.print(vertex+" ");
        myList.add(vertex);
        int num;
        Iterator<Integer> i =this.graph.getAdjacent(vertex).iterator();
        while (i.hasNext())
        {
            num = i.next();
            if (!visited[num])
                dfs(num,visited);
        }
    }
    
    public IndexedGraph getTranspose()
    {
    	IndexedGraph gr = new ArrayGraph(this.graph.getNumberOfVerticies());
        for (int v = 0; v < this.graph.getNumberOfVerticies(); v++)
        {
            Iterator<Integer> itr =this.graph.getAdjacent(v).iterator();
            while(itr.hasNext())
                gr.getAdjacent(itr.next()).add(v);
        }
        return gr;
    }
  
    public void fillOrder(int vertex, boolean visited[], Stack<Integer> st)
    {
        visited[vertex] = true;
        Iterator<Integer> itr = this.graph.getAdjacent(vertex).iterator();
        while (itr.hasNext())
        {
            int num = itr.next();
            if(!visited[num])
                fillOrder(num, visited, st);
        }
  
        st.push(vertex);
    }
  
    public void getMaxSubgraph()
    {
        Stack<Integer> st = new Stack<>();
        boolean visited[] = new boolean[this.graph.getNumberOfVerticies()];
        for(int i = 0; i < this.graph.getNumberOfVerticies(); i++) {
            visited[i] = false;
            fillOrder(i, visited, st);
        }  
        for (int i = 0; i < this.graph.getNumberOfVerticies(); i++)
            visited[i] = false;
  
        while (st.empty() == false)
        {
            int vertex = (int)st.pop();
            if (visited[vertex] == false) {
            	myList = new ArrayList<>();
                dfs(vertex, visited);
                System.out.println();
                if(maxList !=null && myList.size() > maxList.size()) {
                	maxList = myList;
                }
            }
        }
    }
}