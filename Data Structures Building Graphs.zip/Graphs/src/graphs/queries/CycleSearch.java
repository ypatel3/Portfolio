package graphs.queries;

import java.util.Iterator;
import java.util.LinkedList;

import graphs.IndexedGraph;

/**
 * @author <Yash>
 */
public class CycleSearch {
	/**
	 * @param g the graph to search
	 */
	IndexedGraph graph;

	public CycleSearch(IndexedGraph g) {
		this.graph = g;
	}

	Boolean isCyclicUtil(int vertex, Boolean visited[], int source) {
		visited[vertex] = true;
		Integer i;
		Iterator<Integer> it = this.graph.getAdjacent(vertex).iterator();
		while (it.hasNext()) {
			i = it.next();
			if (!visited[i]) {
				if (isCyclicUtil(i, visited, vertex))
					return true;
			}
			else if (i != source)
				return true;
		}
		return false;
	}

	/**
	 * @return true if the graph contains a cycle
	 */
	public boolean containsCycle() {
		int noOfVertices = this.graph.getNumberOfVerticies();
		Boolean visited[] = new Boolean[noOfVertices];
		for (int i = 0; i < noOfVertices; i++)
			visited[i] = false;
		for (int u = 0; u < noOfVertices; u++) {
			if (!visited[u])
				if (isCyclicUtil(u, visited, -1))
					return true;
		}

		return false;
	}
}