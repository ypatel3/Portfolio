package graphs.queries;

import java.util.Collection;
import graphs.IndexedGraph;

/**
 * @author <Yash>
 */
public class DepthFirstSearch
{
	/**
	 * @param g - the graph to search
	 * @param source - the starting vertex to search 
	 */
	DepthFirstPath depthPath;
	boolean pathExist;
	public DepthFirstSearch(IndexedGraph g, int source)
	{
		depthPath = new DepthFirstPath(g, source);
	}

	/**
	 * Check connectivity to the source vertex
	 * @param vertex - the vertex to check connectivity
	 * @return true if connected
	 */
	public boolean isConnected(int vertex)
	{
		if(depthPath.maxList.contains(vertex)) {
			return true;
		}
		return false;
	}
	

	/**
	 * Determine the number of vertices in the subgraph
	 * @return the count
	 */
	public int getCount()
	{
		return depthPath.getCount();
	}

	/**
	 * Return a path from the vertex provided to the original source
	 * @param to any vertex in the graph
	 * @return a collection of vertices that is the path, or 
	 *   an empty collection if the vertex is not connected
	 */
	public Collection<Integer> getPath(int to)
	{
		return depthPath.getPath(to);
	}
}