package graphs.queries;

import java.util.Iterator;

import graphs.IndexedGraph;

/**
 * @author <Yash>
 */
public class DepthFirstConnectivity
{
	/**
	 * @param g - the graph to search
	 */
	IndexedGraph graph;
	public DepthFirstConnectivity(IndexedGraph g)
	{
		this.graph = g;
	}


    boolean dfsSearch(int v, boolean visited[], boolean bool, int to)
    {
    	if(this.graph.getAdjacent(v).contains(to)) {
    		bool = true;
    		return bool;
    	}
        visited[v] = true;
        Iterator<Integer> i = this.graph.getAdjacent(v).iterator();
        while (i.hasNext()) {
            int n = i.next();
            if (!visited[n])
                bool = dfsSearch(n, visited, false, to);
        }
        return bool;
    }
	
	/**
	 * Determine if two vertices are connected 
	 * @param from - the first vertex id
	 * @param to - the second vertex id
	 * @return true if connected
	 */
	
	public boolean connected(int from, int to)
	{
        boolean visited[] = new boolean[this.graph.getNumberOfVerticies()];
        boolean b = dfsSearch(from, visited, false, to);
        return b;
	}
	
	/**
	 * Determines the number of subgraphs
	 * @return the count of subgraphs in the graph
	 */
	public int getNumberOfDisconnectedSubgraphs()
	{
		boolean[] visited = new boolean[this.graph.getNumberOfVerticies()];
        int count = 0;
        int index;
        while((index = checkGraphIsVisited(visited))!=-1){
            dfs(index, visited);
            count++;
        }
        return count;
	}
	
	public int checkGraphIsVisited(boolean[] visited){

        for (int i = 0; i <visited.length ; i++) {
            if(!visited[i])
                return i;
        }
        return -1;
    }
	
	public void dfs(int v, boolean[] visited) {
		visited[v] = true;
        Iterator<Integer> i = this.graph.getAdjacent(v).iterator();
        while (i.hasNext()) {
            int n = i.next();
            if (!visited[n])
                dfs(n, visited);
        }
    }
}