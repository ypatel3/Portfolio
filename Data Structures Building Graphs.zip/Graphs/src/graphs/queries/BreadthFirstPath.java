package graphs.queries;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import graphs.IndexedGraph;

/**
 * @author <Yash>
 */
public class BreadthFirstPath
{
	/**
	 * @param g - the graph to search
	 * @param source - the initial vertex to start the search
	 */
	IndexedGraph g;
	int source;
	boolean isConnected = false;
	public BreadthFirstPath(IndexedGraph g, int source){
		this.g = g;
		this.source = source;
	}

	/**
	 * Return a path from the vertex provided to the original source
	 * @param to any vertex in the graph
	 * @return a collection of vertices that is the path, or 
	 *   an empty collection if the vertex is not connected
	 */
	public Collection<Integer> getPath(int to)
	{
		System.out.println("\n");
		List<Integer> visitedVertices = new ArrayList<>();
		boolean visited[] = new boolean[this.g.getNumberOfVerticies()];
		List<Integer> path = new ArrayList<>();
		LinkedList<Integer> queue = new LinkedList<Integer>();
		visited[to]=true;
		visitedVertices.add(to);
        queue.add(to);
        int el;
        boolean b;
        while (queue.size() != 0)
        {
        	b = false;
            el = queue.poll();
            Iterator<Integer> itr = this.g.getAdjacent(el).iterator();
            for(Integer val:this.g.getAdjacent(el)) {
            	if(! visitedVertices.contains(val)) {
            		b = true;
            	} 
            }
            if(!b) {
            	continue;
            }
            path.add(el);
            if(this.g.getAdjacent(el).contains(this.source)) {
            	path.add(this.source);
            	break;
            }
            while (itr.hasNext())
            {
                int n = itr.next();
                if(visitedVertices.contains(n)) {
                	continue;
                }
                if (!visited[n])
                {
                    visited[n] = true;
                    visitedVertices.add(n);
                    queue.add(n);
                }
            }
        }
		return path;
	}
	
	/**
	 * Check connectivity to the source vertex
	 * @param vertex - the vertex to check connectivity
	 * @return true if connected
	 */
	public boolean isConnected(int vertex)
	{
		return this.isConnected;
	}

	/**
	 * Determine the number of vertices in the subgraph
	 * @return the count
	 */
	public int getCount()
	{
		boolean visited[] = new boolean[this.g.getNumberOfVerticies()];
		List<Integer> path = new ArrayList<>();
		LinkedList<Integer> queue = new LinkedList<Integer>();
		visited[source]=true;
        queue.add(source);
        int el;
        while (queue.size() != 0)
        {
            el = queue.poll();
            path.add(el);
            Iterator<Integer> itr = this.g.getAdjacent(el).iterator();
            while (itr.hasNext())
            {
                int n = itr.next();
                if (!visited[n])
                {
                    visited[n] = true;
                    queue.add(n);
                }
            }
        }
        int count = 0;
        for (int i=0; i<visited.length; i++) {        	
        	if(visited[i]) {
        		count ++;
        	}
        }
        if(count == this.g.getNumberOfVerticies()) {
        	this.isConnected = true;
        }else {
        	this.isConnected = false;
        }
		return count;
	}
}