package graphs.test.queries;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import graphs.ArrayGraph;
import graphs.IndexedGraph;
import graphs.queries.DepthFirstSearch;
import graphs.test.GraphTestHelper;
import ledger.LoggedTest;

/**
 * @author Tony
 */
public class SearchTest extends LoggedTest
{
    @Test		
    @GradedTest(name="Test DepthFirstSearch", max_score=10)
    public void testPath()
    {
    	IndexedGraph g = new ArrayGraph(GraphTestHelper.LINKED_COUNT);
    	GraphTestHelper.setupGraph(g, false);
    	DepthFirstSearch uut = new DepthFirstSearch(g, GraphTestHelper.COWORKER);
    	assertEquals("Count does not match ", GraphTestHelper.UNLINKED_COUNT, uut.getCount());
    	assertTrue("Mom is not connected", uut.isConnected(GraphTestHelper.MOM));
    	assertFalse("Mayor is connected and should not be", uut.isConnected(GraphTestHelper.MAYOR));
    	
    	GraphTestHelper.link(g);
    	uut = new DepthFirstSearch(g, GraphTestHelper.COWORKER);
    	assertEquals("Count does not match ", GraphTestHelper.LINKED_COUNT, uut.getCount());
    	assertTrue("Mayor is not connected", uut.isConnected(GraphTestHelper.MAYOR));
    }	

	private static final String CODE_FILE= "src/graphs/queries/DepthFirstSearch";
	@BeforeClass
	public static void grabCode()
	{
		LoggedTest.grabCode(CODE_FILE);
	}
}