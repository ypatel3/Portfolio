package graphs.test.queries;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import graphs.ArrayGraph;
import graphs.IndexedGraph;
import graphs.queries.CycleSearch;
import graphs.test.GraphTestHelper;
import ledger.LoggedTest;

/**
 * @author Tony
 */
public class CycleTest extends LoggedTest
{
    @Test		
    @GradedTest(name="Test BreadthFirstPath", max_score=10)
    public void testPath()
    {
    	IndexedGraph g = new ArrayGraph(GraphTestHelper.LINKED_COUNT);
    	GraphTestHelper.setupGraph(g, false);
    	CycleSearch uut = new CycleSearch(g);
    	assertTrue("A cycle should exist", uut.containsCycle());

    	g.removeEdge(GraphTestHelper.MOM, GraphTestHelper.SON);
    	g.removeEdge(GraphTestHelper.SON, GraphTestHelper.DAUGHTER);
    	g.removeEdge(GraphTestHelper.DAD, GraphTestHelper.DAUGHTER);
    	g.removeEdge(GraphTestHelper.DAUGHTER, GraphTestHelper.NEIGHBOR);
    	uut = new CycleSearch(g);
    	assertFalse("A cycle should not exist after removing selected family edges", uut.containsCycle());
    }	

	private static final String CODE_FILE= "src/graphs/queries/CycleSearch";
	@BeforeClass
	public static void grabCode()
	{
		LoggedTest.grabCode(CODE_FILE);
	}
}