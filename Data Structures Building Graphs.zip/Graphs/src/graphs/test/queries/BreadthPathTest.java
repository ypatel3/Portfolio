package graphs.test.queries;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.BeforeClass;
import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import graphs.ArrayGraph;
import graphs.IndexedGraph;
import graphs.queries.BreadthFirstPath;
import graphs.test.GraphTestHelper;
import ledger.LoggedTest;

/**
 * @author Tony
 */
public class BreadthPathTest extends LoggedTest
{
    @Test		
    @GradedTest(name="Test BreadthFirstPath", max_score=10)
    public void testPath()
    {
    	IndexedGraph g = new ArrayGraph(GraphTestHelper.LINKED_COUNT);
    	GraphTestHelper.setupGraph(g, false);
    	BreadthFirstPath uut = new BreadthFirstPath(g, GraphTestHelper.COWORKER);
    	assertArrayEquals("The path to the custodian does not match", 
    			          GraphTestHelper.CUSTODIAN_BREADTH_PATH, uut.getPath(GraphTestHelper.CUSTODIAN).toArray());
    	assertEquals("Count does not match ", GraphTestHelper.UNLINKED_COUNT, uut.getCount());
    	assertFalse("Mayor is connected and should not be", uut.isConnected(GraphTestHelper.MAYOR));

    	GraphTestHelper.link(g);
    	uut = new BreadthFirstPath(g, GraphTestHelper.COWORKER);
    	assertEquals("Count does not match ", GraphTestHelper.LINKED_COUNT, uut.getCount());
    	assertArrayEquals("The path to the custodian does not match", 
		          GraphTestHelper.MAYOR_BREADTH_PATH, uut.getPath(GraphTestHelper.MAYOR).toArray());
    	
    }	

	private static final String CODE_FILE= "src/graphs/queries/BreadthFirstPath";
	@BeforeClass
	public static void grabCode()
	{
		LoggedTest.grabCode(CODE_FILE);
	}
}