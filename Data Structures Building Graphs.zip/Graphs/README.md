# Graphs
Setting up a Basic Graph (up to 20 points)

The most basic type of graph we can build uses a simple array and indexes each of the included vertices with a sequential integer value.  To get warmed up with graphs, this exercise asks you to build a simple indexed graph where you will track the edges and basic operations around the graph.  Implement the ArrayGraph class methods as described in the IndexedGraph  interface.

Setting up a Symbol Graph (up to 20 points)

Indexed graphs are great, but they also put a separation between the data and the graph.  A Symbol Table (Java Map) is a plausible way to implement a graph allowing for any data type to become a vertex so long as it has either a hashCode or implementation of Comparable provided.  It also allows for dynamic graphs!

This second optional part challenges you to complete the SymbolGraph class which implements the generic Graph interface.  The test cases use String as the generic data type, but in theory it is quite flexible.  You may need to do a bit of research on generics to fully understand this code, but you should be able to build the code even without a full understanding of generics.  
