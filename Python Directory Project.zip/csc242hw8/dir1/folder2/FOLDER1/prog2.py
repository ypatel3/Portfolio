print("This is another program.")
