print("This is a program.")
