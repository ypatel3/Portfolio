# CSC 242
# Assignment 8 template
# Yash Patel

# Other than pythontutor.com you are not allowed to use any online
# resources when completing assignments. You may not use the live
# tutoring part of pythontutor.com, only the visualization tool.

# Mihir Parmar and Ruchit Patel
# We worked from start to finish on zoom
# If you did not collaborate with anyone, say that
# Files without the above information will earn a 0

# Include doc strings for full credit

# The functions must be recursive and may not use global variables.
# You may not define any helper functions or modify the header of the
# functions in any way.

# You can change the import statements if you like
import os
from html.parser import HTMLParser
from urllib.request import urlopen

# Should use a loop but the majority of the work will be done
# using recursion
# Question 1
def getPyDir(path):
    'function that takes a string representing a name of a directory as a parameter and returns the full name of the first directory'
    def getPyDir(path):
        ans = str
        val = str
        for item in os.listdir(path):
            if item[0] != '.':
                n = os.path.join(path,item)
                if os.path.isfile(n):
                    if n.lower().endswith('.py'):
                        ans = path
                        return ans
                elif os.path.isdir(n):
                    val = getPyDir(n)
                    if val != None:
                        return val

# Should use a loop but the majority of the work will be done
# using recursion
# Note that the function needs to have a variable that is set at
# the top of the function, modified in the body of the function,
# and involved in the return statement ONLY at the END
# Question 2
def countSparseDirs(path):
    'function that takes a string representing a directory path as a parameter and returns the number of directories'
    def countSparseDirs(path):
        count = 0
        hasFiles = False
        for item in os.listdir(path):
            if item[0] != '.':
                n = os.path.join(path,item)
                if os.path.isfile(n):
                    hasFiles = True
                elif os.path.isdir(n):
                    count += countSparseDirs(n)
        if hasFiles == False:
            count +=1
        return count

# Question 3
# Write this class
# Include doc strings for all methods
class AltCollector(HTMLParser):
    'a subclass of the HTMLParser class'
    def __init__(self):
        'constructor calls the parent class constructor and sets a variable'
        HTMLParser.__init__(self)
        self.altVal = []

    def handle_starttag(self, tag, attrs):
        'method collects the values associated with the alt attribute in image tags['
        if tag.lower() == 'img':
            for item in attrs:
                if item[0].lower() == 'alt':
                    self.altVal.append(item[1])
        
    def getAlt(self):
        'returns the list of alt values collected by the parser'
        return self.altVal

# For reference only -- do not change
def testAParser(url):
    content = urlopen(url).read().decode()
    parser = AltCollector()
    parser.feed(content)
    return parser.getAlt()

# Question 4
# Write this class
# Include doc strings for all methods
class TagCounter(HTMLParser):
    'a subclass of the HTMLParser class'
    def __init__(self):
        'constructor calls the parent class constructor and creates an empty dictionary'
        HTMLParser.__init__(self)
        self.tags = {}

    def handle_starttag(self, tag, attrs):
        'method checks if the tag is not already in the dictionary'
        if tag not in self.tags:
            self.tags[tag] = 1
        else:
            self.tags[tag] += 1
       
    def getTags(self):
        'returns the dictionary of tag-frequency pairs'
        return self.tags

# For reference only -- do not change
def testTParser(url):
    content = urlopen(url).read().decode()
    parser = TagCounter()
    parser.feed(content)
    return parser.getTags()
