#Yash Patel
#CSC 241-405
#Assignment 8
#I worked alone

#1.

import random
def bridgeHands(deckCards):
    'return a dictionary where North, South, West, East with different hands'
    random.shuffle(deckCards)
    d = dict()
    d['North'] = tuple(deckCards[:13])
    d['South'] = tuple(deckCards[13:26])
    d['East'] = tuple(deckCards[26:39])
    d['West'] = tuple(deckCards[39:52])
    return d

#2.

def primeFac(n):
    'return list that contains positive prime factorization'
    primes = []
    d = 2
    while d*d <= n:
        while (n % d) == 0:
            primes.append(d)
            n=n/d
        d=d+1
    if n > 1:
       primes.append(n)
    return primes

#3. 

def reverse(pb):
    'return a dictionary that reverse phone numbers to the names'
    reversepb = {}
    for key in pb:
        value = pb[key]
        reversepb[value] = key
    return reverse


#4.

def zipf(file):
    'print a function that takes a file name and confirms zipf observation'
    infile = open(file)
    content = infile.read()
    infile.close()
    content.lower()
    content.strip(',!?-."')
    wordslst= content.split()
    wordslst.sort()
    totalwords = len(wordslst)
    wordfreq = []
    for word in wordslst:
        wordfreq.append(wordslst.count(word))
    print(wordfreq)


