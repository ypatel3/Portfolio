# MapApps

#1 Raffle App (25 points)
Most of the time, a raffle is quite simple.  People purchase raffle tickets, and at the end of the raffle or more ticket is picked to reward a prize.  The problem in the modern age is the risk of fraud.  The simple raffle includes prenumbered tickets and the owner’s option to write their name on the back before submitting.  These tickets are now quite easy to purchase and, given modern printing, easy to counterfeit.  A clever fraudster could quickly generate mock tickets and submit them without purchase.  Computing cannot always prevent fraud (or sometimes honest mistakes) but can help identify what went wrong by tracking audit data.  
This exercise asks you to realize a data structure to track every ticket submitted to a raffle.  You must identify the order of the tickets submitted and identify when a duplicate ticket (the same ticket number) is submitted.  The first ticket counts as the eligible entry, but the system must track every submission.  Your task is to implement the BasicTicketManager class using any combination of data structures and algorithms you see appropriate.
a)	add() – Add a ticket to the raffle
b)	numberOfEligibleEntries() – return the number of unique ticket numbers submitted
c)	totalTicketsSubmitted() – return the total number of tickets submitted
d)	pick() – randomly select a winning ticket from the remaining tickets (and remove that ticket)
e)	getAllSubmissionsFor() – get all of the tickets submitted for the provided ticket number
The exercise intends you to use various data structures (e.g., Lists, Sets, Maps – a.k.a. symbol tables) to solve a ‘real world’ problem.  You should attempt at least a plan for this problem on your own, but if you feel stuck, you can watch the following sequence of videos to build a solution to this problem.  In this case, you can submit an approach to this solution identical to my own, so long as you complete the coding and testing.  Remember, one of the best ways to learn clever design strategies is to build code while mimicking an existing solution actively.  Simply looking at it is not as helpful as working with and ensuring you understand its construction.
https://www.youtube.com/playlist?list=PLfNrTgOJi893Cfr4264IiNBhV0ho3Of_S
* This playlist includes some materials on basic lists and sets.  You can watch this as a refresher or jump directly to the demo as you desire. 
 
#2 Simple Cipher (20 points)
The earliest forms of encryption simply shifted the letters of a message in a predetermined manner to hide the contents from prying eyes.  A very basic example of this is as follows.  
Original Message:  HELLO 
“Shifted” Message: IFMMP
In this encryption, each letter of the “shifted” message is the next letter after the original letter.  While the new message is quite indecipherable immediately, it is fairly simple to crack when you know what to look for.  A slightly more complex form of simple encryption maps one character to another to jumble up the message much more haphazardly.  Each letter is mapped to another letter as follows:
Original Message:  HELLO 
“Mapped” Message: NDYYk 
This encryption of this message relies on the use of a symbol table!  A symbol table maps between the known letters of the alphabet and randomly paired alternatives.  Since we have the original message, we can see at least part of the symbol table:
	H -> N, E -> D, L -> Y, O -> k, and so on…
This assignment sets up a simple ciphering application that you need to complete by filling in the following functions.
a)	generateKey() – Generate the symbol table that maps above.  The best keys are generated randomly for each specific use.  If you need help on how to get started with the symbol table or how to generate random keys, check out the helper video on this week’s playlist
b)	generateDecryptKey(key) – Given the encryption key generated above, create the decryption key as a symbol table.  The decryption key is merely the ‘flipped mapping’.  From the example above, the new symbol table would have a key N that pairs to the value H, the exact opposite of the original symbol table.  
c)	encrypt(phrase, key) – Use the provided key to create an encrypted version of the message.  Your symbol table provides the mapping for each letter!
d)	decrypt(phrase, key) – The key is now the decryption key, and the message is the one you encrypted before.  This returns the message to its original contents, and if you are clever, it should be a very quick and short implementation!
 
#3 COVID Data Analysis (50 points)
Knowing how to program gives you access to vast stores of data to perform your own analysis, either professionally or for personal interest.  This exercise includes a set of data on COVID infections from around the world as comma-separated values (CSV).  To guide the process of analyzing this file, I have provided a design, and you must simply implement a few key functions.
a)	readFile() - Import the data from the CSV file – This function must load each line, parse its contents, and save the values into the COVIDData Class defined as part of the project.  
A sample of the report (in the following table) shows that you must ‘throw-away’ the first line of the file, as it is not data, but just the header for the data.  Our program does not use every value from the file.  You can ignore the geold, countryterritoryCode, and the cumulative entries in this file.  
Sample from the start of the data file
dateRep,day,month,year,cases,deaths,countriesAndTerritories,geoId,countryterritoryCode,popData2019,continentExp,Cumulative_number_for_14_days_of_COVID-19_cases_per_100000
3/10/20,3,10,2020,5,0,Afghanistan,AF,AFG,38041757,Asia,0.97524412
2/10/20,2,10,2020,17,0,Afghanistan,AF,AFG,38041757,Asia,1.08564912
1/10/20,1,10,2020,14,0,Afghanistan,AF,AFG,38041757,Asia,1.04096138
30/09/2020,30,9,2020,15,2,Afghanistan,AF,AFG,38041757,Asia,1.04884745
  
a)	generateReport() - Report all the data for one country – Once the data is loaded, we can do all sorts of things with it.  One simple option is to filter the data, in this case, to limit the data to a single country.  Use the provided list of all the data to print out only the requested country’s data to the provided filename.  The data in this file is not the original data from the file, but the content of the object you filled in a).  The format of each line in that file should be comma-separated and match:
       <country>, <continent>, <population>, <day>, <month>, <year>, <cases>, <deaths>
b)	getCasesByContinent() – As you add data in a) you can also fill a symbol table to track the number of total cases on each continent.  Modify readDataFile() to also fill the defined symbol table casesPerContinent and then this function to return the data as defined.
c)	getCountriesOnContinent() – As you add data in a) you can also fill a symbol table to track the list of countries on each continent.  Modify readDataFile() to also fill the defined symbol table countriesPerContinent and then this function to return the data as defined.
d)	getPopulationForContinent() - As you add data in a) you can also fill a symbol table to store the population of each country (populationPerCountry).  Modify readDataFile() to also fill populationPerCountry.  Then use populationPerCountry to create a new symbol table that stores the population of each continent.

 
#4 Bird Watchers (30 points)
A society of ornithologists wants to track the sightings of their network of bird watchers around town and needs some automation to help track the growing data set.  They have planned some basic functionality they need you to write in a bird-watching ledger.  The ledger receives a Sighting object, and the date the sighting occurred.  Your task is to store the sightings and provide the various behaviors listed below to query the data.
a)	addBirdSighting() – Add a bird sighting to the ledger.  You can store these sightings in any appropriate data structure(s) for satisfying the later requirements.
b)	getNumberOfDaysInLedger() – Return the total number of days on which a watcher made a report (do not count days without filings)
c)	getNumberOfSightingsInLedger() – Return the total number of sightings reported
d)	birdsSeenEachDay() – Count the number of birds seen day and return the results as an array with the count for each day that includes a report
e)	printLedger() – print the entire ledger day by day
f)	numberOfSightingsFor() – Report the number of times a specified bird type has been spotted across the entire ledger.
g)	allBirdsSpottedAt() – For a given location, report all of the various types of birds spotted at that location.

