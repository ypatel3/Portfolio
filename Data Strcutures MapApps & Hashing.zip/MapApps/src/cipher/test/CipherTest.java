package cipher.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;

import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import cipher.SimpleCipher;
import ledger.LoggedTest;

/**
 * @author Tony
 */
public class CipherTest extends LoggedTest
{
    @Test		
    @GradedTest(name="Test generateKey()", max_score=5)
    public void testGenerateKey() 
    {
    	SimpleCipher sc = new SimpleCipher();
    	Map<Character, Character> key = sc.getKey();
    	assertEquals("Key should contain 52 values, lower case and capitals", 52, key.size());
    	int THRESHOLD = 3; // The number that is OK to be the same since it is randomly selected
    	int same = 0;
    	for (Map.Entry<Character, Character> e : key.entrySet())
    	{
    		if (e.getKey() == e.getValue())
    		{
    			same = same + 1;
    		}
    	}
    	assertFalse("Your map should have fewer than " + THRESHOLD + " unciphered letters but you had " + same, same > THRESHOLD);
    }

    @Test		
    @GradedTest(name="Test generateDecriptKey()", max_score=5)
    public void testGenerateDecryptKey() 
    {
    	SimpleCipher sc = new SimpleCipher();
    	Map<Character, Character> key = sc.getKey();
    	Map<Character, Character> decryptKey = sc.getDecryptKey();
    	assertEquals("Key should contain 52 values, lower case and capitals", 52, key.size());
    	assertEquals("The size of the key and decrypt key must match", key.size(), decryptKey.size());
    	
    	for (Character c : decryptKey.keySet())
    	{
    		assertEquals("The encryption keys do not match!", key.get(decryptKey.get(c)), c);
    	}
    }
    
    @Test		
    @GradedTest(name="Test encrypt() and decrypt()", max_score=10)
    public void testEncrypt() 
    {
		String[] phrases = {"Hello Maps", "Map=Dictionary=Symbol Table", 
                            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"};

		SimpleCipher sc = new SimpleCipher();
		for (String phrase : phrases)
		{
			String ciphered = sc.encrypt(phrase);
			assertNotEquals("Message did not change", phrase, ciphered);
			assertEquals("The decrypted does not match the original", phrase, sc.decrypt(ciphered));
		}
    }    

	private static final String CODE_FILE= "src/cipher/SimpleCipher";
	@BeforeClass
	public static void grabCode()
	{
		LoggedTest.grabCode(CODE_FILE);
	}
}