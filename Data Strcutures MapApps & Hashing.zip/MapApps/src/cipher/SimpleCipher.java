package cipher;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author <Your Name Here>
 */
public class SimpleCipher 
{
	Map<Character, Character> key;
	Map<Character, Character> decryptKey;

	public SimpleCipher() 
	{
		key = generateKey();
		decryptKey = generateDecryptKey(key);
	}
	
	/**
	 * Build the encryption key as a map where the key is a letter and 
	 * the value is its ciphered value.  The map needs to include A-Z and 
	 * a-z (no need to encrypt other characters)
	 */
	private Map<Character, Character> generateKey()
	{
		Map<Character, Character> key = new TreeMap<Character, Character>();
		return key;
	}

	/**
	 * Generate a map that is the 'flip' of the key.  
	 * A call to generate key must happen first
	 */
	private Map<Character, Character> generateDecryptKey(Map<Character, Character> key)
	{
		Map<Character, Character> decryptKey = new TreeMap<Character, Character>();
		return decryptKey;
	}

	/**
	 * Encrypt the given message
	 * @param message - to encrypt
	 * @return a ciphered message
	 */
	public String encrypt(String message)
	{
		return message;
	}
	
	/**
	 * Decrypt the given message
	 * @param ciphered - to decrypt
	 * @return the original message
	 */
	public String decrypt(String ciphered)
	{
		return ciphered;
	}
	
	public Map<Character, Character> getKey()
	{
		return key;
	}

	public Map<Character, Character> getDecryptKey() {
		return decryptKey;
	}
}