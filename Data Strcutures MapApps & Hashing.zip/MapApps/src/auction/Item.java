package auction;

public class Item
{
	private long id;
	private String description;
	private double reservePrice;
	
	public Item(long id, String description, double reservePrice)
	{
		super();
		this.id = id;
		this.description = description;
		this.reservePrice = reservePrice;
	}

	@Override
	public String toString()
	{
		return description + System.lineSeparator() + "ID:" + id + " Reserve price: $" + reservePrice;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (id != other.id)
			return false;
		return true;
	}

	public long getId()
	{
		return id;
	}

	public String getDescription()
	{
		return description;
	}

	public double getReservePrice()
	{
		return reservePrice;
	}
}