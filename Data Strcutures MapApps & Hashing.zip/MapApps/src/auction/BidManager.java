package auction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BidManager {

	/**
	 * Create your data structures within the constructor!
	 */
	Map<Item, List<Bid>> bids;
	Map<Item, Bid> winBid;
	Map<String, List<Bid>> userBids;
	static int counter = 0;

	public BidManager() {
		bids = new HashMap<>();
		winBid = new HashMap<>();
		userBids = new HashMap<>();
	}

	/**
	 * Get the total number of items that are up for auction (not total bids!)
	 * 
	 * @return the total number of items that are up for auction
	 */
	public int getAuctionCount() {
		return bids.keySet().size();
	}

	/**
	 * Add a bid for an item in the auction
	 * 
	 * @param bid the bid details, included in the object
	 * @return true, if the bid is now the high bidder
	 */
	public boolean addBid(Bid bid) {
		// System.out.println("Bid # "+
		// counter++ + " ==> " + bid.getItem() + " : " + bid.getUsername() + " : " +
		// bid.getAmount() + "\n");
		Boolean bool = false;
		List<Bid> perItemBids = null;
		List<Bid> perUserBids = null;
		String username = bid.getUsername();
		Item item = bid.getItem();
		if (bid.getAmount() >= item.getReservePrice()) {
			if (bids.containsKey(item)) {
				perItemBids = bids.get(item);
				perItemBids.add(bid);
				bids.put(item, perItemBids);
				if (bid.getAmount() > winBid.get(item).getAmount()) {
					winBid.put(item, bid);
					// System.out.println("WINNING BID: "+
					// counter++ + " ==> " + bid.getItem() + " : " + bid.getUsername() + " : " +
					// bid.getAmount() + "\n");
					// this.getHighestBid(item);
					bool = true;
				}
			} else {
				bids.put(item, new ArrayList<Bid>(Arrays.asList(bid)));
				winBid.put(item, bid);
				// System.out.println("WINNING BID: "+
				// counter++ + " ==> " + winBid.get(bid.getItem())+"\n");
				bool = true;
			}
		}
		if (userBids.containsKey(username)) {
			perUserBids = userBids.get(username);
			perUserBids.add(bid);
			userBids.put(username, perUserBids);
		} else {
			userBids.put(username, new ArrayList<Bid>(Arrays.asList(bid)));
		}

		if (bool)
			return true;
		// this.getHighestBid(item);
		return false;
	}

	/**
	 * Get the highest bidder for the selected item
	 * 
	 * @param onItem the item to check
	 * @return the Bid if a bidder is present, else null
	 */
	public Bid getHighestBid(Item onItem) {
		return winBid.get(onItem);
	}

	/**
	 * Get the history of all bids made on the provided item
	 * 
	 * @param onItem the item up for bidding
	 * @return a list of all bids (even if not the highest at the time)
	 */
	public List<Bid> getBidHistory(Item onItem) {
		return bids.get(onItem);
	}

	/**
	 * Get a history of bids for the specified user
	 * 
	 * @param username a user to search
	 * @return a list of all bids on any item this user has bid upon
	 */
	public List<Bid> getBidHistory(String username) {
		return userBids.get(username);
	}

	/**
	 * Removes all bids for the provided user on this item as the possible
	 * highest bidder and from history
	 * 
	 * @param username the user to remove
	 * @param onItem   the item from which to remove bids
	 */
	public void removeBidder(String username, Item onItem) {
		List<Bid> itemBids = bids.get(onItem);
		List<Bid> toRemove = new ArrayList<>();
		for (Bid b : itemBids) {
			if (b.getUsername().equals(username)) {
				toRemove.add(b);
			}
		}
		itemBids.removeAll(toRemove);
		Bid max = itemBids.get(0);
		for(Bid bid:itemBids) {
			if(bid.getAmount() > max.getAmount()) {
				max = bid;
			}
		}
		bids.put(onItem, itemBids);
		winBid.put(onItem, max);
	}
}
