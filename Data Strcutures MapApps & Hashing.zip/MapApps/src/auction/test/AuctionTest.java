package auction.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import auction.Bid;
import auction.BidManager;
import auction.Item;
import ledger.LoggedTest;
import test.RandomHelper;

public class AuctionTest extends LoggedTest
{
	private ItemGenerator gen = new ItemGenerator();
	private BidManager uut;
	private int itemCount = 10;
	private List<Item> items;
	private Random r = new Random();

	@Before
	public void setup()
	{
		uut = new BidManager();
		items = gen.generateList(itemCount);
	}
	
    @Test		
    @GradedTest(name="Test basic add() and get", max_score=5)
    public void testAdd() 
    {
    	 for (Item i : items)
    	 {
    		 Bid b = gen.generateBid(i, true);
    		 assertTrue("This should have been the high bidder", uut.addBid(b));
    		 assertEquals("Did not return the bid just added", b, uut.getHighestBid(i));
    	 }
    	 assertEquals("Number of items in the auction did not match", items.size(), uut.getAuctionCount());
    }
    
    @Test		
    @GradedTest(name="Test reserve prices", max_score=5)
    public void testReserve()
    {
    	for (Item i : items)
	   	{
	   		Bid b = new Bid((String) RandomHelper.getRandom(r, ItemGenerator.USERS), i, 0.00);
	   		assertFalse("This should not have been the high bidder", uut.addBid(b));
	   		assertEquals("Should not have added the last bid", null, uut.getHighestBid(i));
	   	}
	   	assertEquals("Number of items in the auction did not match", 0, uut.getAuctionCount());
	   	assertTrue("Did not add when reserve met", uut.addBid(gen.generateBid(gen.generate(), true)));
    }

    @Test		
    @GradedTest(name="Test history", max_score=5)
    public void testHistory()
    {
    	List<Bid> allBids = new ArrayList<>();
    	Item testItem = gen.generate();
    	Bid lastBid = gen.generateBid(testItem, true);
    	allBids.add(lastBid);
   		uut.addBid(lastBid);
   		
   		
	  	for (int i = 0; i < 5 + r.nextInt(10); i++)
	   	{
	   		Bid insufficient = new Bid((String) RandomHelper.getRandom(r, ItemGenerator.USERS), testItem, lastBid.getAmount() - 0.005);
	    	allBids.add(insufficient);
	   		assertFalse("This should not have been the high bidder", uut.addBid(insufficient));
	   		assertNotEquals("Should not have added this bid (last bid: " + lastBid +")", insufficient, uut.getHighestBid(testItem));
	   		
	   		lastBid = new Bid((String) RandomHelper.getRandom(r, ItemGenerator.USERS), testItem, lastBid.getAmount() + 1);
	    	allBids.add(lastBid);
	   		assertTrue("This should have been the high bidder", uut.addBid(lastBid));
	   		assertEquals("Did not add next highest bid", lastBid, uut.getHighestBid(testItem));
	   	}
	  	List<Bid> actualHistory = uut.getBidHistory(testItem);
	   	assertEquals("Number of final bids did not match", allBids.size(), actualHistory.size());
	   	assertEquals("List of final bids did not match", allBids, actualHistory);
	   	assertNull("Returned history when none expected", uut.getBidHistory(new Item(0, "nothing", 0)));
    }
    
    @Test		
    @GradedTest(name="Test user history", max_score=5)
    public void testUserHistory()
    {
    	List<Bid> allBids = new ArrayList<>();
    	Item testItem = gen.generate();
    	Bid bid = gen.generateBid(testItem, false);
    	for (int itemNumber = 0; itemNumber < 5; itemNumber++)
    	{
        	int numberOfBids = r.nextInt(10);
	    	for (int i = 0; i < numberOfBids; i++)
	    	{
	    		allBids.add(bid);
	    		uut.addBid(bid);
	    		bid = new Bid(bid.getUsername(), testItem, bid.getAmount() + r.nextInt(10));
	    	}
	    	testItem = gen.generate();
    	}
    	List<Bid> actualHistory = uut.getBidHistory(bid.getUsername());
    	assertNotNull("No list returned", actualHistory);
	   	assertEquals("Number of bids did not match", allBids.size(), actualHistory.size());
	   	assertEquals("List of bids did not match", allBids, actualHistory);
	   	assertNull("Returned history when none expected", uut.getBidHistory("nobody"));
    }
    
    @Test		
    @GradedTest(name="Test removeBidder()", max_score=10)
    public void testRemoveBidder()
    {
    	testAdd();
    	
    	Item testItem = gen.generate();
    	String removeUsername = "broke1";
    	uut.addBid(new Bid(removeUsername, testItem, 0.01));
    	int numberOfBids = 5 + r.nextInt(10);
    	for (int i = 0; i < numberOfBids; i++)
    	{
    		uut.addBid(gen.generateBid(testItem, true));
    	}
    	
    	Bid highest = uut.getHighestBid(testItem);
    	uut.addBid(new Bid (removeUsername, testItem, highest.getAmount() + 0.01));
    	List<Bid> withRemoved = uut.getBidHistory(testItem);
    	int beforeSize = withRemoved.size();
    	int userHistorySize = uut.getBidHistory(removeUsername).size();
    	uut.removeBidder(removeUsername, testItem);
    	assertEquals("Did not remove all of the bidder's bids", beforeSize - 2, uut.getBidHistory(testItem).size());
    	assertEquals("Highest bid does not match expected", highest, uut.getHighestBid(testItem));
    	assertEquals("User History changed", userHistorySize, uut.getBidHistory(removeUsername).size());
    }   
    
 	private static final String CODE_FILE= "src/auction/BidManager";
 	@BeforeClass
 	public static void grabCode()
 	{
 		LoggedTest.grabCode(CODE_FILE);
 	}
}