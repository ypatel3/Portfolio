package auction.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import auction.Bid;
import auction.Item;
import test.RandomHelper;

public class ItemGenerator
{
	public static final String[] ADJECTIVES = {"Extra large", "Purple", "New and Improved", "Vintage"};
	public static final String[] ITEMS = {"Computer", "Donut", "Sports Car", "Comic Book", "Jacket"};
	public static final String[] USERS = {"big$2", "cheapSkate", "uberCollector", "anon123", "antiqueHunter", "grannyGrabber", "bidderMcBiddy", "nikkiDog", "jasperLee", "hankyBoi", "razzleBerry", "goooose", "crowleyElMago"};
	private Random r = new Random();
	private Map<Long, Item> items = new HashMap<>();
	
	public Item generate()
	{
		long id = r.nextLong();
		Item i = items.get(id);
		if (i == null)
		{
			String name = RandomHelper.getRandom(r, ADJECTIVES) + " " + RandomHelper.getRandom(r, ITEMS);
			double price = r.nextInt(100) + r.nextInt(99)/100 + 0.01;
			i = new Item(id, name, price);
			items.put(id, i);
		}
		return i;
	}
	
	public List<Item> generateList(int size)
	{
		List<Item> items = new ArrayList<>();
		for (int i = 0; i < size; i++)
		{
			items.add(generate());
		}
		return items;
	}
	
	public Bid generateBid(Item on, boolean mustExceedReserve)
	{
		double amount = 0;
		if (mustExceedReserve)
		{
			amount = on.getReservePrice();
		}
		amount += r.nextInt(20) + r.nextInt(100)/100;
		return new Bid((String) RandomHelper.getRandom(r, USERS), on, amount);
	}
}