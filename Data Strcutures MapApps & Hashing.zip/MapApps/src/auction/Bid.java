package auction;

public class Bid
{
	private String username;
	private Item item;
	private double amount;
	
	public Bid(String username, Item item, double amount)
	{
		this.username = username;
		this.item = item;
		this.amount = amount;
	}

	@Override
	public String toString()
	{
		return "Bid [username=" + username + ", item=" + item + ", bid amount= $" + amount + "]";
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(amount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((item == null) ? 0 : item.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bid other = (Bid) obj;
		if (Double.doubleToLongBits(amount) != Double.doubleToLongBits(other.amount))
			return false;
		if (item == null)
		{
			if (other.item != null)
				return false;
		} else if (!item.equals(other.item))
			return false;
		if (username == null)
		{
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}

	public String getUsername()
	{
		return username;
	}

	public Item getItem()
	{
		return item;
	}

	public double getAmount()
	{
		return amount;
	}
}