package santa;

public class Person
{
	private String first;
	private String last;
	private String suffix;

	public Person(String first, String last)
	{
		this.first = first;
		this.last = last;
	}
	
	@Override
	public String toString()
	{
		return first + " " + last + (suffix != null ?  " " + suffix : "");
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((first == null) ? 0 : first.hashCode());
		result = prime * result + ((last == null) ? 0 : last.hashCode());
		result = prime * result + ((suffix == null) ? 0 : suffix.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		if (first == null)
		{
			if (other.first != null)
				return false;
		} else if (!first.equals(other.first))
			return false;
		if (last == null)
		{
			if (other.last != null)
				return false;
		} else if (!last.equals(other.last))
			return false;
		if (suffix == null)
		{
			if (other.suffix != null)
				return false;
		} else if (!suffix.equals(other.suffix))
			return false;
		return true;
	}

	public String getSuffix()
	{
		return suffix;
	}

	public void setSuffix(String suffix)
	{
		this.suffix = suffix;
	}

	public String getFirst()
	{
		return first;
	}

	public String getLast()
	{
		return last;
	}
}