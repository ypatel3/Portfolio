package santa;

import java.util.List;

public class SecretSanta
{

	/**
	 * Given the list of participants, match each person as a 'recipient' who will receive a gift from a 
	 * 'Secret Santa'.  Every person on the list must appear as both a 'Santa' and a 'recipient'.  
	 * @param participants the list of all people participating.
	 */
	public SecretSanta(List<Person> participants)
	{
	}

	/**
	 * Return the 'recipient' for the name provided as 'Santa'
	 * @param forSanta the person giving
	 * @return the person receiving
	 */
	public Person getRecipient(Person forSanta)
	{
		return null;
	}
	
	/**
	 * The total number of people participating.
	 * @return
	 */
	public int getParticipantCount()
	{
		return 0;
	}
	
	/**
	 * Create a String that lists each 'Santa' and 'recipient' pair on their own line such as
	 *   Santa Name 1 -> recipient name 1
	 *   Santa Name 2 -> recipient name 2
	 *   ...
	 * @return A string formatted as described
	 */
	public String getListOfParticipants()
	{
		return "";
	}
}