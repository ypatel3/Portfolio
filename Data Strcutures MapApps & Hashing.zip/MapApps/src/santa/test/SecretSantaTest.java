package santa.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import ledger.LoggedTest;
import santa.Person;
import santa.SecretSanta;
import test.RandomHelper;

public class SecretSantaTest extends LoggedTest
{
	private static final String[] FIRSTS= {"Bilbo", "Hari", "Frodo", "Sam", "Paul", "Katniss", 
										   "Cruella", "Luke", "Leia", "Han", "Anakin", "Kelsier", "Locke", 
										   "Kvothe", "Gandalf", "Caine", "Jean", "Carlo", "Galdo", };
	private static final String[] LASTS = {"Baggins", "Michalson", "Baggins", "Gamgee", "Atraties", "Everdeen",
										   "De'ville", "Skywalker", "Organa", "Solo", "Lamora", "Palapatine", 
										   "Tannen", "Sanza", };
	private int numberOfParticipants = 100;
	private List<Person> participants;
	private SecretSanta uut;
	
	@Before
	public void setup()
	{
		Random r = new Random();
		participants = new ArrayList<>();
		for (int i = 0; i < numberOfParticipants; i++)
		{
			Person addMe = new Person((String) RandomHelper.getRandom(r, FIRSTS), 
									  (String) RandomHelper.getRandom(r, LASTS));
			
			for (Person existing : participants)
			{
				if (existing.getFirst().equals(addMe.getFirst()) && 
					existing.getLast().equals(addMe.getLast()))
				{
					if (existing.getSuffix() == null)
					{
						addMe.setSuffix("II");
					} else
					{
						addMe.setSuffix(existing.getSuffix() + "I");
					}
				}
			}
			
			participants.add(addMe);
		}
	}
	
    @Test		
    @GradedTest(name="Test Secret Santa", max_score=5)
    public void testMatches()
    {
		uut = new SecretSanta(new ArrayList<>(participants));
		
		assertEquals("The number of participants does not match", numberOfParticipants, uut.getParticipantCount());
		
		List<Person> checklist = new ArrayList<>(participants);
		for (Person p : participants)
		{
			Person receipient = uut.getRecipient(p);
			assertNotEquals("The person was assigned themselves!", receipient, p);
			assertNotNull("A participant was not assigned as a Santa (" + p + ")", receipient);
			checklist.remove(receipient);
		}
		assertTrue("Some of the participants did not get assigned as a recipient (" + checklist + ")", checklist.isEmpty());
    }	

    @Test		
    @GradedTest(name="Test Secret Santa List", max_score=0)
    public void testList()
    {
    	testMatches();
    	System.out.println(uut.getListOfParticipants());
    }

    @Test		
    @GradedTest(name="Bunches", max_score=5)
    public void testBunches()
    {
    	for (int i = 0; i < 1000; i++)
    	{
    		testMatches();
    	}
    }
    
 	private static final String CODE_FILE= "src/santa/SecretSanta";
 	@BeforeClass
 	public static void grabCode()
 	{
 		LoggedTest.grabCode(CODE_FILE);
 	}
}