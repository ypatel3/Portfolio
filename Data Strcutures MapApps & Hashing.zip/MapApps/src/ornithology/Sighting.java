package ornithology;

/**
 * @author Tony
 */
public class Sighting
{
	private ActivityPeriod time;
	private Bird bird;
	private String location;

	public Sighting(ActivityPeriod time, Bird bird, String location)
	{
		super();
		this.time = time;
		this.bird = bird;
		this.location = location;
	}

	public ActivityPeriod getTime()
	{
		return time;
	}

	public Bird getBird()
	{
		return bird;
	}

	public String getLocation()
	{
		return location;
	}

	@Override
	public String toString()
	{
		return "Sighting [time=" + time.label + ", bird=" + bird.label + ", location=" + location + "]";
	}
}