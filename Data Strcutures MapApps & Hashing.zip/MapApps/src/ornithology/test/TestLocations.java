package ornithology.test;

import java.util.Random;

/**
 * @author Tony
 */
public class TestLocations
{
	private Random r = new Random();
	private static final String[] LOCATIONS = 
		{
			"Park",
			"Beach",
			"Mall",
			"City Hall",
			"High School",
			"City Dump",
			"Forest Preserve",
			"Downtown Highrise"
		};
	
	public String getRandom()
	{
		return LOCATIONS[r.nextInt(LOCATIONS.length)];
	}
}
