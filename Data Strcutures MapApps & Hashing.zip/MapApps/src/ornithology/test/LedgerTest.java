package ornithology.test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import org.junit.BeforeClass;
import org.junit.Test;

import com.gradescope.jh61b.grader.GradedTest;

import ledger.LoggedTest;
import ornithology.ActivityPeriod;
import ornithology.Bird;
import ornithology.BirdWatchingLedger;
import ornithology.Sighting;

/**
 * @author Tony
 */
public class LedgerTest extends LoggedTest 
{
	private Random r = new Random();
	private TestLocations locations = new TestLocations();
	private int totalSightings;
	private int[] dailySightings;
	private String randomLocation;
	private Set<Bird> atThatLocation;
	private Bird randomBird;
	private int randomBirdHits;
	
	private Sighting generateSighting()
	{
		totalSightings = totalSightings + 1;
		Sighting sighting = new Sighting(ActivityPeriod.values()[(r.nextInt(ActivityPeriod.values().length))],
				                         Bird.values()[r.nextInt(Bird.values().length)],
				                         locations.getRandom());
		if (randomLocation == null)
		{
			randomLocation = sighting.getLocation();
			atThatLocation = new TreeSet<Bird>();
			atThatLocation.add(sighting.getBird());
		} else if (randomLocation.equals(sighting.getLocation()))
		{
			atThatLocation.add(sighting.getBird());
		}
		
		if (randomBird == null)
		{
			randomBird = sighting.getBird();
			randomBirdHits = 1;
		} else if (sighting.getBird() == randomBird)
		{
			randomBirdHits = randomBirdHits + 1;
		}
			
		return sighting;
	}

	private void fillLedger(int days, BirdWatchingLedger ledger)
	{
		TestDates dates = new TestDates(days);
		dailySightings = new int[days];
		for (int day = 0; day < days; day++)
		{
			Date current = dates.getNextDate();
			int numberOfSightings = r.nextInt(15) + 1;
			dailySightings[day] = numberOfSightings;
			for (int sighting = 0; sighting < numberOfSightings; sighting++)
			{
				ledger.add(current, generateSighting());
			}
		}
	}
	
    @Test		
    @GradedTest(name="Test add(), getNumberOfDaysInLedger(), and getNumberOfSightingsInLedger()", max_score=10)
    public void testAdd() 
    {
    	BirdWatchingLedger ledger = new BirdWatchingLedger();
    	int numberOfDays = r.nextInt(10) + 5;
    	fillLedger(numberOfDays, ledger);
    	assertEquals("Number of days does not match", numberOfDays, ledger.getNumberOfDaysInLedger()); 
    	assertEquals("Number of sightings does not match", totalSightings, ledger.getNumberOfSightingsInLedger()); 
    }

    @Test		
    @GradedTest(name="Test getBirdSeenEachDay()", max_score=5)
    public void testDailySightings() 
    {
    	BirdWatchingLedger ledger = new BirdWatchingLedger();
    	int numberOfDays = r.nextInt(10) + 5;
    	fillLedger(numberOfDays, ledger);
    	assertArrayEquals("The number of sightings each day did not match", dailySightings, ledger.getBirdSeenEachDay());
    }
 
    @Test		
    @GradedTest(name="Test numberOfSightingsFor()", max_score=5)
    public void testBirdHits()
    {
    	BirdWatchingLedger ledger = new BirdWatchingLedger();
    	int numberOfDays = r.nextInt(10) + 5;
    	fillLedger(numberOfDays, ledger);
    	assertEquals("Your sightings for the random bird" + randomBird + " did not match", randomBirdHits, ledger.numberOfSightingsFor(randomBird));
    }

    @Test		
    @GradedTest(name="Test birdsSpottedAt()", max_score=5)
    public void testLocation()
    {
    	BirdWatchingLedger ledger = new BirdWatchingLedger();
    	int numberOfDays = r.nextInt(10) + 5;
    	fillLedger(numberOfDays, ledger);
    	assertArrayEquals("Your sightings at the random location " + randomLocation + " did not match", atThatLocation.toArray(), ledger.birdsSpottedAt(randomLocation).toArray());
    }
    
    @Test		
    @GradedTest(name="Test printableLedger()", max_score=5)
    public void testPrint() 
    {
    	BirdWatchingLedger ledger = new BirdWatchingLedger();
    	int numberOfDays = r.nextInt(3) + 3;
    	fillLedger(numberOfDays, ledger);
    	String result = ledger.printableLedger();
    	assertTrue("The printed ledger was empty", result.length() > 0);
    	System.out.println(result);
    }

	private static final String CODE_FILE= "src/ornithology/BirdWatchingLedger";
	@BeforeClass
	public static void grabCode()
	{
		LoggedTest.grabCode(CODE_FILE);
	}
}