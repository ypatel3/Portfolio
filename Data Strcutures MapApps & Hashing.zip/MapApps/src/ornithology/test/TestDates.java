package ornithology.test;

import java.util.Calendar;
import java.util.Date;

/**
 * @author Tony
 */
public class TestDates
{
	private Calendar date;
	
	public TestDates(int numberOfDays)
	{
		date = Calendar.getInstance();
		date.add(Calendar.DATE, -numberOfDays);
		date.set(Calendar.HOUR, 0);
		date.set(Calendar.MINUTE, 0);
		date.set(Calendar.SECOND, 0);
		date.set(Calendar.MILLISECOND, 0);
	}

	public Date getNextDate()
	{
		Date next = date.getTime();
		date.add(Calendar.DATE, 1);
		return next;
	}
}