package ornithology;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * @author <Your Name Here>
 */
public class BirdWatchingLedger 
{
	//......................................................................
	// Define any data structures you need to solve the problem here!
	
	/**
	 * Add a sighting to the ledger for the given date
	 * @param date - the day/month/year of the sighting, time is zeroed out.  
	 *   Dates can be in any order and may not be chronological
	 * @param sighting the sighting object to save
	 */
	public void add(Date date, Sighting sighting)
	{
		
	}
	
	/**
	 * Retreive the number of unique days recorded in the ledger
	 * @return a non-negative integer 
	 */
	public int getNumberOfDaysInLedger()
	{
		return 0;
	}
	
	/**
	 * Retrieve the total number of sightings added to the ledger across all days
	 * @return a non-negative integer
	 */
	public int getNumberOfSightingsInLedger()
	{
		return 0;
	}
	
	/**
	 * Retrieve the number of birds observed on each day in the ledger
	 * @return an integer array, where each entry is a day in the ledger in date order.
	 *   The array skips any 'missing days'.  For example, if the ledger contains a 
	 *   sighting for January 1st and January 3rd but not January 2nd, then the 
	 *   array will be of size 2, NOT 3.  It only reports dates added to the ledger, not all dates.
	 */
	public int[] getBirdSeenEachDay()
	{
		int[] dailyTotal = new int[0];
		return dailyTotal;
	}
	
	/**
	 * Create a string that is printable.  When printed, the format should 
	 * be similar to the following:
	 * 
	 *   Mon Dec 28 12:00:00 EST 2020
	 *   .....................
	 *   Sighting [time=6PM - 12AM, bird=Hummingbird, location=City Hall]
	 *   Sighting [time=12AM - 6 AM, bird=Gull, location=Beach]
	 *   Tue Dec 29 12:00:00 EST 2020
	 *   .....................
	 *   Sighting [time=6AM - 12PM, bird=Sparrow, location=Downtown Highrise]
	 *   Sighting [time=6PM - 12AM, bird=Toucan, location=Park]
	 *   
	 * @return a formatted string, including new line characters embedded
	 */
	public String printableLedger()
	{
		StringBuilder printable = new StringBuilder();
		return printable.toString();
	}
	
	/**
	 * Retrieve the number of sightings in the entire ledger for the given bird
	 * @param bird - target of the query
	 * @return the number of times the bird appears
	 */
	public int numberOfSightingsFor(Bird bird)
	{
		return 0;
	}
	
	/**
	 * Return each type of bird spotted at a given location
	 * @param location - the target of the query
	 * @return a set of birds that were sighted at that location
	 */
	public Collection<Bird> birdsSpottedAt(String location)
	{
		Collection<Bird> birds = new ArrayList<Bird>();
		return birds;
	}
}