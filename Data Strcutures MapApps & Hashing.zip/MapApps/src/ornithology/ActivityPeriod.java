package ornithology;

/**
 * @author Tony
 */
public enum ActivityPeriod
{
	MORNING("6AM - 12PM"),
	AFTERNOON("12PM - 6PM"),
	EVENING("6PM - 12AM"),
	NIGHT("12AM - 6 AM");
	
	public final String label;

	private ActivityPeriod(String label)
	{
		this.label = label;
	}	
}
