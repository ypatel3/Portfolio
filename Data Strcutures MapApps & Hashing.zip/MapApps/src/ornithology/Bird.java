package ornithology;

/**
 * @author Tony
 */
public enum Bird
{
	SPARROW("Sparrow"),
	LARK("Lark"),
	ROBIN("Robin"),
	CARDINAL("Cardinal"),
	TOUCAN("Toucan"),
	EAGLE("Eagle"),
	FALCON("Falcon"),
	CHICKEN("Chicken"),
	HERON("Heron"),
	OWL("Owl"),
	HUMMINGBIRD("Hummingbird"),
	WOODPECKER("Woodpecker"),
	DUCK("Duck"),
	GULL("Gull");
	
	public final String label;

	private Bird(String label)
	{
		this.label = label;
	}
}
