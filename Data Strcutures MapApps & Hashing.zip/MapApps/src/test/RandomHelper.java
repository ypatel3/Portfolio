package test;

import java.util.Random;

public class RandomHelper
{
	public static Object getRandom(Random r, Object[] from)
	{
		return from[r.nextInt(from.length)];
	}
}
