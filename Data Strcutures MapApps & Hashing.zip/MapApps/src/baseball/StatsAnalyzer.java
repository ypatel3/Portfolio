package baseball;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class StatsAnalyzer
{
	private Map<String, Map<Integer, TeamInfo>> teamData = new HashMap<>();
	private Map<Integer, TeamInfo> bestCostPerWin;
	private Map<Integer, TeamInfo> worstCostPerWin;
	private int winCount;
	private long salaryTotal;
	private long totalAttendance;
	private TeamInfo bestAttendance;
	private TeamInfo worstAttendance;
	
	/**
	 * Computes salary statistics from the files provided
	 * @param franchiseFile - the filename containing the Key for relating teams to franchises
	 * @param teamFile - the filename containing the information on individual teams each year
	 * @param salariesFile - the filename containing the salary data
	 * @throws IOException
	 */
	public StatsAnalyzer(String franchiseFile, String teamFile, String salariesFile) throws IOException
	{
	}

	/**
	 * Get the team information for a single team
	 * @param teamCode - the team code from the data
	 * @param year - the desired year
	 * @return the loaded team info for the specified team
	 */
	public TeamInfo getTeamInfo(String teamCode, int year)
	{
		return null;
	}
	
	/**
	 * Provides the average salary paid per win for all teams in the dataset
	 * @return the average in dollars/win
	 */
	public int getAverageCostPerWin()
	{
		return 0;
	}
	
	public List<TeamInfo> costPerWinRankings(int year)
	{
		return null;
	}

	/**
	 * Get the team with the least amount of money spent per win across the entire dataset
	 * @return the team with the lowest salary/win
	 */
	public TeamInfo getBestCostPerWinAllTime()
	{
		return null;
	}

	/**
	 * Get the team with the most amount of money spent per win across the entire dataset
	 * @return the team with the highest salary/win
	 */
	public TeamInfo getWorstCostPerWinAllTime()
	{
		return null;
	}
	
	/**
	 * Get the team with the least amount of money spent per win across at each win total
	 * @return a map where the key is the number of wins and the value is the team with the best salary/win
	 */
	public Map<Integer, TeamInfo> getBestCostPerWinTotalAllTime()
	{
		return null;
	}

	/**
	 * Get the team with the most amount of money spent per win across at each win total
	 * @return a map where the key is the number of wins and the value is the team with the worst salary/win
	 */
	public Map<Integer, TeamInfo> getWorstCostPerWinTotalAllTime()
	{
		return null;
	}

	/**
	 * Provides the average salary paid per win for all teams in the dataset
	 * @return the average in dollars/win
	 */
	public int getAverageSpentPerAttendee()
	{
		return 0;
	}
	
	/**
	 * Get the team with the least amount of money spent per attendee across the entire dataset
	 * @return the team with the lowest salary/attendee
	 */
	public TeamInfo getBestSpentPerAttendeeAllTime()
	{
		return null;
	}

	/**
	 * Get the team with the most amount of money spent per attendee across the entire dataset
	 * @return the team with the highest salary/attendee
	 */
	public TeamInfo getWorstSpentPerAttendeeAllTime()
	{
		return null;
	}
}