package covid;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author <Your Name Here>
 */
public class COVIDDataAnalyzer
{
	// You will need to define attributes to manage the data here!
	
	/**
	 * Read the data in the know WHO format from the specified file
	 * @param filename the name of the file to read
	 * @return a list of COVIDData objects read from the file
	 * @throws ParseException 
	 */
	public List<COVIDData> readFile(String filename) throws IOException, ParseException
	{
		List<COVIDData> data = new ArrayList<>();
		return data;
	}
	
	/**
	 * Create a new report filtered to the specified country and stored in the specified
	 * file.  The new file should use the following format
	 * <country>, <continent>, <population>, <day>, <month>, <year>, <cases>, <deaths>
	 * @param country - The country to report upon
	 * @param toFilename - The destination filename to save the report
	 * @throws IOException 
	 */
	@SuppressWarnings("deprecation")
	public void generateReport(String country, String toFilename) throws IOException
	{
	}
	
	/**
	 * Retrieve the number of cases on each continent
	 * @return a map with the key of the continent name and the 
	 *  value the total number of cases on that continent
	 */
	public long getCasesForContinent(String continent)
	{
		return 0;
	}

	/**
	 * Retrieve the population of a continent
	 * @param continent - the target
	 * @return a map with the key of the continent name and the 
	 *  value the population of that continent
	 */
	public long getPopulationForContinent(String continent)
	{
		return 0;
	}	
	
	/**
	 * Retrieve all the countries on a continent
	 * @param continent - the target
	 * @return a list of countries
	 */
	public Collection<String> getCountriesOnContinent(String continent)
	{
		Collection<String> countries = new ArrayList<>();
		return countries;
	}
}