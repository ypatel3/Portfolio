/*-------------------------------------------------------------------------*
 *---									---*
 *---		wordCounter.c						---*
 *---									---*
 *---	    This file defines a program that counts the words in a file	---*
 *---	using 2 different data-structures.				---*
 *---									---*
 *---	----	----	----	----	----	----	----	----	---*
 *---									---*
 *---	Version 1.0					Joseph Phillips	---*
 *---									---*
 *-------------------------------------------------------------------------*/

#include	"wordCounterHeader.h"

//  PURPOSE:  To hold the size of the buffer to read.
int		textLen;


//  PURPOSE:  To remove the '\n' character in the string pointed to by '\n',
//	if it exists.  No return value.
void  		removeNewline	(char*		cPtr
				)
{
  cPtr	= strchr(cPtr,'\n');

  if  (cPtr != NULL)
    *cPtr = '\0';
}


//  PURPOSE:  To return '1' if a word is found at address '*positionHandle',
//	and to place a lowercased version of the word into 'word', advance
//	'*positionHandle' past the word, and return '1' if such a word exists.
//	Returns '0' if no more words are found between the starting address of
//	'*positionHandle' and the ending '\n' or '\0' character.
int		didGetWord	(char**		positionHandle,
				 char*		word
				)
{
  while  ( (**positionHandle != '\n')  &&
	   (**positionHandle != '\n')  &&
	   !isalnum(**positionHandle)
	 )
    (*positionHandle)++;

  if  ( (**positionHandle == '\n') || (**positionHandle == '\0') )
    return(0);

  do
  {
    *word	= tolower(**positionHandle);
    word++;
    (*positionHandle)++;
  }
  while  ( isalnum(**positionHandle) );

  *word	= '\0';

  return(1);
}



int		main		(int		argc,
				 char*		argv[]
				)
{
  char	filename[SMALL_TEXT_LEN];
  FILE*	filePtr;
  int	choice;
  int	length	= 1024;

  textLen	= 4 * length;

  printf("File name to read: ");
  fgets(filename,SMALL_TEXT_LEN,stdin);
  removeNewline(filename);

  filePtr	= fopen(filename,"r");

  if  (filePtr == NULL)
  {
    fprintf(stderr,"Could not open %s\n",filename);
    exit(EXIT_FAILURE);
  }

  do
  {
    char	choiceText[SMALL_TEXT_LEN];

    printf
	("Which algorithm would you like to run:\n"
	 "(1) Count words with tree\n"
	 "(2) Count words with linked-list\n"
	 "\n"
	 "Your choice? "
	);
    fgets(choiceText,SMALL_TEXT_LEN,stdin);
    choice = atoi(choiceText);
  }
  while  ( (choice < 1)  ||  (choice > 2) );

  printf("\n\n");

  switch  (choice)
  {
  case 1 :
    {
      struct TreeNode*	rootPtr	= buildTree(filePtr);

      printTree(rootPtr);
      freeTree (rootPtr);
    }
    break;

  case 2 :
    {
      struct ListNode*	firstPtr= buildList(filePtr);

      printList(firstPtr);
      freeList (firstPtr);
    }

    break;
  }

  fclose(filePtr);
  return(EXIT_SUCCESS);
}
