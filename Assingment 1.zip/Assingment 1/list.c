/*-------------------------------------------------------------------------*
 *---									---*
 *---		list.c							---*
 *---									---*
 *---	    This file defines functions that build, print and free a	---*
 *---	list of struct ListNode instances for the  wordCounter program.	---*
 *---									---*
 *---	----	----	----	----	----	----	----	----	---*
 *---									---*
 *---	Version 1.0					Joseph Phillips	---*
 *---									---*
 *-------------------------------------------------------------------------*/

#include	"wordCounterHeader.h"


//  PURPOSE:  To build and return a list of struct ListNode instances telling
//	the counts of the words found in file '*filePtr'.
struct ListNode*
		buildList	(FILE*		filePtr
				)
{
  struct ListNode*	firstPtr	= NULL;
  struct ListNode*	lastPtr		= NULL;
  struct ListNode*	listRun;
  struct ListNode*	newPtr;
  char*			line		= (char*)malloc(textLen);
  char			word[SMALL_TEXT_LEN];

  while  ( fgets(line,textLen,filePtr) != NULL )
  {
    char*	lineRun	= line;

    while  ( didGetWord(&lineRun,word) )
    {

      for  (listRun = firstPtr;  listRun != NULL;  listRun = listRun->nextPtr_)
	if  (strcmp(listRun->wordCPtr_,word) == 0)
	  break;

      if  (listRun == NULL)
      {
	newPtr   = (struct ListNode*)malloc(sizeof(struct ListNode));

	newPtr->wordCPtr_  = strdup(word);
	newPtr->count_	   = 1;
	newPtr->nextPtr_   = NULL;

	if  (firstPtr == NULL)
	  firstPtr = newPtr;
	else
	  lastPtr->nextPtr_ = newPtr;

	lastPtr	= newPtr;
      }
      else
	(listRun->count_)++; 

    }

  }

  free(line);
  return(firstPtr);
}


//  PURPOSE:  To print the list pointed to by '*firstPtr'.  No return value.
void		printList	(struct ListNode*	firstPtr
				)
{
  struct ListNode*	listRun;

  for  (listRun = firstPtr;  listRun != NULL;  listRun = listRun->nextPtr_)
    printf("%s\t%d\n",listRun->wordCPtr_,listRun->count_);

}


//  PURPOSE:  To free the list pointed to by '*firstPtr'.  No return value.
void		freeList	(struct ListNode*	firstPtr
				)
{
  struct ListNode*	listRun;
  struct ListNode*	nextPtr;

  for  (listRun = firstPtr;  listRun != NULL;  listRun = nextPtr)
  {
    nextPtr	= listRun->nextPtr_;

    free(listRun->wordCPtr_);
    free(listRun);
  }

}
