/*-------------------------------------------------------------------------*
 *---									---*
 *---		tree.c							---*
 *---									---*
 *---	    This file defines functions that build, print and free a	---*
 *---	tree of struct TreeNode instances for the  wordCounter program.	---*
 *---									---*
 *---	----	----	----	----	----	----	----	----	---*
 *---									---*
 *---	Version 1.0					Joseph Phillips	---*
 *---									---*
 *-------------------------------------------------------------------------*/

#include	"wordCounterHeader.h"


//  PURPOSE:  To build and return a tree of struct TreeNode instances telling
//	the counts of the words found in file '*filePtr'.
struct TreeNode*
		buildTree	(FILE*		filePtr
				)
{
  struct TreeNode*	rootPtr	= NULL;
  struct TreeNode*	listPrev;
  struct TreeNode*	listRun;
  struct TreeNode*	newPtr;
  int			compResult;
  char*			line	= (char*)malloc(textLen);
  char			word[SMALL_TEXT_LEN];

  while  ( fgets(line,textLen,filePtr) != NULL )
  {
    char*	lineRun	= line;

    while  ( didGetWord(&lineRun,word) )
    {
      listPrev	= NULL;

      for  (listRun = rootPtr;  listRun != NULL;  )
      {

	if  ( (compResult = strcmp(listRun->wordCPtr_,word)) == 0)
	  break;

	listPrev = listRun;

	if  (compResult > 0)
	  listRun = listRun->leftPtr_;
	else
	  listRun = listRun->rightPtr_;

      }

      if  (listRun == NULL)
      {
	newPtr	= (struct TreeNode*)malloc(sizeof(struct TreeNode));

	newPtr->wordCPtr_  = strdup(word);
	newPtr->count_	   = 1;
	newPtr->leftPtr_   = NULL;
	newPtr->rightPtr_  = NULL;

	if  (rootPtr == NULL)
	  rootPtr = newPtr;
	else
	if  (compResult > 0)
	  listPrev->leftPtr_ = newPtr;
	else
	  listPrev->rightPtr_ = newPtr;

      }
      else
	(listRun->count_)++;
    }

  }

  free(line);
  return(rootPtr);
}


//  PURPOSE:  To print the subtree rooted at '*nodePtr'.  No return value.
void		printTree	(struct TreeNode*	nodePtr
				)
{
  if  (nodePtr == NULL)
    return;

  printTree(nodePtr->leftPtr_);
  printf("%s\t%d\n",nodePtr->wordCPtr_,nodePtr->count_);
  printTree(nodePtr->rightPtr_);
}


//  PURPOSE:  To free the subtree rooted at '*nodePtr'.  No return value.
void		freeTree	(struct TreeNode*	nodePtr
				)
{
  if  (nodePtr == NULL)
    return;

  freeTree(nodePtr->leftPtr_);
  freeTree(nodePtr->rightPtr_);
  free(nodePtr->wordCPtr_);
  free(nodePtr);
}
